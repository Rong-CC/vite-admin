<template>
  <div class="content">
    <div class="contain">
      <div class="top-show">
        <div class="left">
          <el-carousel indicator-position="none" height='100%'>
            <el-carousel-item v-for="(item,index) in lunboList" :key="index">
              <img :src="item">
            </el-carousel-item>
          </el-carousel>
        </div>
        <div class="right">
          <div class="title" @click='toPage("CommentDetail")'>
            动漫区公告
          </div>
          <div class="desc">
            <p>
              近期几位版主现实事务较忙，未能及时处理大家的举报和建议，在此深表歉意！
            </p>
            <p> 还请大家继续支持论坛工作，欢迎在帖内举报按钮和私信建议，我们会竭尽所能尽快处理。</p>
            <p>
              对于存有争议的动画，还请各位继续秉持“求同存异”原则，圈地自萌，不喜勿看，谨慎讨论。
              凡涉及人身攻击言辞，一律从重处理。
            </p>
          </div>
          <div class="other">
            <div class="other-item" v-for="(item,index) in other" :key="index">
              <i class="el-icon-s-flag"></i>
              <span>
                {{item}}
              </span>
            </div>
          </div>
          <div class="top-posts">
            <div class="post" v-for="(item,index) in post" :key="index">
              <i class="el-icon-warning-outline"></i>
              <span>
                {{item}}
              </span>
            </div>
          </div>
        </div>

      </div>

      <div class="type-list">
        <div class="type-item" v-for="(item,index) in labels" :key="index">
          <i class="el-icon-s-ticket"></i>
          <span> {{item}}</span>
        </div>
      </div>
      <div class="search">
        <div class="ipts">
          <el-input placeholder="请输入要搜索的帖子" prefix-icon="el-icon-search" v-model="input2">
          </el-input>
        </div>
      </div>
      <div @click='toPage("CommentDetail")'>

      <el-tabs type="border-card" @click.native='toPage("CommentDetail")'>
        <el-tab-pane label="全部">
          <el-table :data="tableData" style="width: 100%" @click.native='toPage("CommentDetail")'>
            <!-- 宽度版心1700px 200  1000px -->
            <el-table-column prop="date" label="类别(漫画讨论)" width="200">
            </el-table-column>
            <el-table-column prop="name" label="标题  " width="1000">
            </el-table-column>
            <el-table-column prop="address" label="作者" width="200">
            </el-table-column>
            <el-table-column prop="num" label="回帖数" width="200">
            </el-table-column>
            <!-- <el-table-column prop="address" label="最热"  width="180">
              </el-table-column> -->
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="最新">
          <el-table :data="tableData" style="width: 100%">
            <!-- 宽度版心1700px 200  1000px -->
            <el-table-column prop="date" label="类别(漫画讨论)" width="200">
            </el-table-column>
            <el-table-column prop="name" label="标题  " width="1000">
            </el-table-column>
            <el-table-column prop="address" label="作者" width="200">
            </el-table-column>
            <el-table-column prop="num" label="回帖数" width="200">
            </el-table-column>
            <!-- <el-table-column prop="address" label="最热"  width="180">
              </el-table-column> -->
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="热门">热门</el-tab-pane>
        <el-tab-pane label="精华">精华</el-tab-pane>
        <el-tab-pane label="排行榜">排行榜</el-tab-pane>
      </el-tabs>
      </div>
      <div class="block">
        <!-- <span class="demonstration">完整功能</span> -->
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
          :current-page="currentPage4" :page-sizes="[10, 20, 30, 100]" :page-size="10"
          layout="total, sizes, prev, pager, next, jumper" :total="400">
        </el-pagination>
      </div>
      <!-- 发布帖子 -->
      <div class="publish">
        <div class="title">
          快速发帖
        </div>
        <div class="row">
          <el-select v-model="value" placeholder="请选择">
            <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
          <div class="ipt">
            <el-input v-model="input" placeholder="输入标题"></el-input>
          </div>
        </div>
        <div class="contxt">
          <div class="style-list">
            <div class="style-item">
              <i class="el-icon-back"></i>
            </div>
            <div class="style-item">
              <i class="el-icon-right"></i>
            </div>
            <div class="style-item">
              <i class="el-icon-s-check"></i>
            </div>
            <div class="style-item sp-style">
              <el-select v-model="value" placeholder="请选择">
                <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </div>
            <div class="style-item">
              <i class="el-icon-picture "></i>
            </div>
            <div class="style-item">
              <i class="el-icon-upload"></i>
            </div>
            <div class="style-item">
              <i class="el-icon-s-tools "></i>
            </div>
          </div>
          <el-input type="textarea" :autosize="{ minRows: 7, maxRows: 12}" placeholder="请输入内容" v-model="textarea2">
          </el-input>
        </div>
        <div class="psh-btn">
          <el-button type="primary">发表帖子<i class="el-icon-upload el-icon--right"></i></el-button>
          <el-link type="warning">发帖规则</el-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      input: '',
      input2: '',
      typeList: ['最新', '热门', '精华'],
      tableData: [{
        date: '[漫画讨论]',
        name: ' [奥たまむし]我也不知道谁才是真爱 第十话党争投票',
        address: '柏拉图的猫',
        num: 1231
        // hot:
      }, {
        date: '[推荐]',
        name: ' 披着BG外衣的朝鲜女同漫画《前世姻缘》 -',
        address: '柏拉图的猫',
        num: 105
      }, {
        date: '[推荐]',
        name: ' 克苏鲁+怪谈风百合韩漫安利《关于外星人空降地球邀请我作挚友这件事》',
        address: '163',
        num: 166
      }, {
        date: '[漫画讨论]',
        name: ' [奥たまむし]我也不知道谁才是真爱 第十话党争投票',
        address: 'hupuha',
        num: 23
      }, {
        date: '[杂谈]',
        name: ' 《無法拒絕孤獨的她》是我的新地雷 ',
        address: '她的後宮',
        num: 177
      }
      ],
      lunboList: [
        require('../static/images/forum/lunbo-1.jpg'),
        require('../static/images/forum/lunbo-2.jpg'),
        require('../static/images/forum/lunbo-3.jpg')
      ],
      labels: ['公告', '活动', '动画讨论', '漫画讨论', '小说套路', '杂谈', '情报', '2.5次元', '翻译资料'],
      other: ['动漫区版规', '求助专用贴'],
      post: ['自制的300App', '新人必看', '换头像任务积分兑换帖'],
      currentPage1: 5,
      currentPage2: 5,
      currentPage3: 5,
      currentPage4: 4,
      options: [{
        value: '选项1',
        label: '小说讨论'
      }, {
        value: '选项2',
        label: '公告'
      }, {
        value: '选项3',
        label: '活动'
      }, {
        value: '选项4',
        label: '动漫讨论'
      }, {
        value: '选项5',
        label: '小说讨论'
      }],
      value: '选择主题分类',
      textarea1: '',
      textarea2: ''
    }
    x`x`
  },
  methods: {
    handleSizeChange (val) {
      // console.log(`每页 ${val} 条`);
    },
    handleCurrentChange (val) {
      // console.log(`当前页: ${val}`);
    },
    toPage (e) {
      console.log(e)
      this.$router.push('/' + e)
    }
  }

}
</script>

<style lang="less" scoped="scoped">
  * {
    box-sizing: border-box;
    font-size: 17px;
  }

  .content {
    width: 100%;
    max-width: 2270px;
    margin: auto;
    margin-top: 80px;

    .contain {
      width: 1700px;
      margin: auto;

      .top-show {
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        background-color: #ffffff;
        padding: 10px 20px;
        margin-bottom: 20px;
        box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);

        .left {
          width: 450px;
          height: 600px;

          .el-carousel {
            width: 100%;
            height: 100%;
            background-color: #2C3E50;

            .el-carousel-item {
              width: 100%;

              img {
                width: 100%;
                height: 100%;
                // height: 100%;
                // width: auto;
              }
            }

            img {
              width: 100%;
              height: 100%;
              // background-color: #ca8f47;
            }
          }
        }

        .right {
          position: relative;
          width: 1100px;
          height: 600px;
          padding: 20px 20px;

          .title {
            font-size: 40px;
            font-weight: 600;
            margin-bottom: 20px;
          }

          .desc {
            p {
              font-size: 18px;
              margin-bottom: 20px;
            }
          }

          .other {
            display: flex;
            align-items: center;
            width: 100%;
            // background-color: #ffffff;
            margin-bottom: 20px;

            .other-item {
              background-color: #fff;
              padding: 10px 25px;
              border-radius: 5px;
              box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
              margin-right: 10px;
              color: #ff0000;
              cursor: pointer;
              font-weight: 600;
              font-size: 17px;
            }
          }

          .top-posts {
            display: flex;

            .post {
              background-color: #fff;
              margin-right: 20px;
              padding: 10px 25px;
              border-radius: 5px;
              box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
              font-weight: 600;
              cursor: pointer;
            }
          }
        }
      }

      .type-list {
        display: flex;
        align-items: center;
        width: 1700px;
        height: 80px;
        background-color: #fff;
        margin-bottom: 10px;
        border-radius: 5px;
        padding: 20px;

        .type-item {
          background-color: #f8f8f8;
          margin-right: 20px;
          padding: 5px 20px;
          border-radius: 6px;
          cursor: pointer;

          i {
            color: #409EFF;
          }
        }
      }

      .search {
        height: 60px;
        background-color: #fff;
        border-radius: 6px;
        margin-bottom: 10px;
        width: 500px;
      }

      .block {
        background-color: #fff;
        padding: 10px 20px;
        margin-bottom: 20px;
      }

      .publish {
        background-color: #fff;
        padding: 10px;

        .title {
          font-size: 20px;
          font-weight: 600;
          padding: 5px;
          margin-bottom: 20px;
        }

        .row {
          display: flex;
          align-items: center;
          margin-bottom: 15px;

          .ipt {
            width: 500px;
            background-color: #409EFF;
          }
        }

        .contxt {
          width: 1200px;
          border: 1px solid #DCDFE6;
          margin-bottom: 10px;

          .style-list {
            display: flex;
            align-items: center;
            height: 60px;
            border: 1px solid #DCDFE6;
            padding: 0px 10px;

            .style-item {
              padding: 5px;
              margin-right: 15px;
              cursor: pointer;
              transition: all .4s;

              &:hover {
                background-color: #555555;
                border-radius: 6px;
                color: #fff;
              }

            }

            .sp-style {
              width: 80px;

              &:hover {
                background-color: sandybrown;
              }
            }

            i {
              font-size: 25px;
              font-weight: 600;
            }
          }
        }

        .psh-btn {
          .el-button {
            margin-right: 20px;
          }
        }
      }
    }
  }
</style>
