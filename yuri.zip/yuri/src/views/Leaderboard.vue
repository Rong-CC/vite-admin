<template>
  <div class="content">

    <el-container class='w-cont'>
      <el-header>
        <div class="title">
          排行榜<span>/Ranking List</span>
        </div>
      </el-header>
      <el-container>
        <el-aside width="230px">
          <el-menu
          :unique-opened='true'
           background-color="#ffffff"
          default-active="2" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose">
            <el-submenu index="1">
              <template slot="title">
                <i class="el-icon-location"></i>
                <span>小说</span>
              </template>
              <el-menu-item-group>
                <template slot="title">轻小说</template>
                <el-menu-item index="1-1">日轻</el-menu-item>
                <el-menu-item index="1-2">国轻</el-menu-item>
              </el-menu-item-group>
              <el-menu-item-group title="分组2">
                <el-menu-item index="1-3">正统</el-menu-item>
              </el-menu-item-group>
              <el-submenu index="1-4">
                <template slot="title">选项4</template>
                <el-menu-item index="1-4-1">选项1</el-menu-item>
              </el-submenu>
            </el-submenu>
            <el-menu-item index="2" @click="toPage(list[0])" >
              <i class="el-icon-menu"></i>
              <span slot="title">漫画</span>
            </el-menu-item>
            <el-menu-item index="3" >
              <i class="el-icon-document"></i>
              <span slot="title">动漫</span>
            </el-menu-item>
            <el-menu-item index="4"  @click="toPage(list[2])">
              <i class="el-icon-setting"></i>
              <span slot="title">人物</span>
            </el-menu-item>
            <el-menu-item index="5">
              <i class="el-icon-setting"></i>
              <span slot="title">剧情</span>
            </el-menu-item>
          </el-menu>
        </el-aside>
        <el-main>
            <router-view>

            </router-view>
        </el-main>
      </el-container>
    </el-container>

  </div>
</template>

<script>
  export default {
    data() {
      return {
        list:['Shousetsu','','Role']
      }
    },
    methods: {
      toPage(e){
        this.$router.push('/'+e)
      } ,
      handleOpen(){

      },
      handleClose(){
        
      }
    }

  }
</script>

<style lang="less" scoped="scoped">
  .content {
    width: 1700px;
    height: 1200px;
    margin: auto;
    margin-top: 80px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
    padding: 20px;

    .w-cont {
      height: 1000px;
      background-color: #ffffff;
      overflow: hidden;
      .el-header{
        box-sizing: content-box;
        padding: 20px;
        .title{
          font-size: 38px;
          font-weight: 600;
          letter-spacing: 3px;
          span{
            font-size: 20px;
          }
        }
      }

      .el-container{
        .el-aside{
          // height: 1200px;
          background-color: #ffffff ;
        }
        .el-main{
          padding: 0px;
          margin-top: 0px;
          padding-top: 0px;
          router-view{
            margin-top: 0px;
            height: 100%;
          }
        }
      }
    }
  }
</style>
