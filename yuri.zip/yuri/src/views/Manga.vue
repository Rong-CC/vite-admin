<template>
  <!-- 主要结构：在于顶部的轮播，-->
  <div class="content">

    <div class="contain">
      <div class="topBar">
        <el-carousel height="330px" :initial-index="acLunbo" :autoplay="false" ref="lunbo">
          <el-carousel-item v-for="item in lunboList" :key="item">
            <img :src="item">
          </el-carousel-item>
        </el-carousel>
        <!-- 略所图 -->
        <div class="loop_pagination">
          <div class="loop_box">
            <div class="loop-item" v-for="(item,index) in lunboList" :key="item" @mouseenter="setIndex(index)">
              <div class="img-contain">
                <img :src="item">
                <span>
                  <!-- 装饰三角 -->
                </span>
              </div>
            </div>
          </div>
        </div>
        <!-- 分类标签，点击更多进入正式的详情页 -->
        <!-- 也有作品类型分类 -->
        <div class="label-nav">
          <div class="label-list">
            <div class="nav" v-for="(item,index) in nav" :key="index">
              {{item}}
            </div>
          </div>
          <div class="label-more">
            <span>更多</span>
            <i class="el-icon-s-unfold"></i>
          </div>
        </div>
      </div>
      <!-- 公告板块 -->
      <div class="notice">
        <!-- 作品标签栏 -->
        <div class="notice-lt">
          <div class="lt-title">
            作品类型
          </div>
          <div class="type-list">
            <div class="item" v-for="(item,index) in workList" :key="item">
              {{item}}
            </div>
          </div>
        </div>
        <!-- 公告栏 -->
        <div class="notice-rt">
          <div class="rt-title">
            公告
          </div>
          <div class="notice-list">
            <div class="notice-item" v-for="(item,index) in noticeList" :key="index">
              {{item}}
            </div>
          </div>
        </div>
      </div>
      <!-- 主题板块 -->
      <div class="manga-main">
        <!-- 热门漫画 -->
        <div class="column">
          <div class="comic_list-hot" v-for="(item,index) in list" :key="index">
            <div class="tit">
              <div class="tit-left">
                <i class="el-icon-medal"></i>
                <span>{{item.name}}</span>
                <!-- 此处作筛选不做分页，提供推荐作品分类的功能 -->
                <ul class="chose">
                  <li :class="{'chose-ac' : index==0}" v-for="(item,index) in typeList">
                    {{item}}
                  </li>
                </ul>
              </div>
              <div class="tit-right">
                <span>更多</span>
                <i class="el-icon-arrow-right"></i>
              </div>
            </div>
            <!-- 漫画列表 -->
            <div class="list">
              <div class="item" v-for="(maItem,index) in item.Manga" :key="index">
                <div class="item-top">
                  <!-- 漫画图片 -->
                  <img :src="maItem.title">
                </div>
                <div class="item-bottom">
                  <div class="bottom-name">
                    {{maItem.name}}
                  </div>
                  <div class="bottom-writer">
                    <span>作者</span> {{maItem.author}}
                  </div>
                  <!-- 编辑推荐栏科协 -->
                  <div class="bottom-desc">
                    留不住的爱情
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="rank">
          <div class="rank-1">
            <div class="title">
              日漫榜单
            </div>
            <div class="list" v-for="(item,index) in lueManga" :key="index">
              <div class="item">
                <div class="item-lt">
                  <span>{{index+1}}</span>
                  {{item.name}}
                </div>
                <div class="item-rt">
                  更新到<span>第13话</span>
                </div>
              </div>
              <div class="item-ac">
                <div class="ac-contain">
                  <div class="item-lt">
                    <div class="index">{{index+1}}</div>
                    <img :src="item.title">
                  </div>
                  <div class="item-rt">
                    <div class="name">
                      {{item.name}}
                    </div>
                    <div class="labels">
                      <div class="label">恋爱</div>
                      <div class="label">治愈</div>
                    </div>
                    <div class="desc">
                      回到家乡工作的温一凡在酒吧偶遇
                      回到家乡工作的温一凡在酒吧偶遇
                      回到家乡工作的温一凡在酒吧偶遇
                    </div>
                    <div class="latest">
                      更新到：<span>13话</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <img src="">
  </div>
</template>

<script>
  export default {
    data() {
      return {
        list: [{
            name: "热门漫画",
            Manga: [{
                title: require("../static/images/rank/manga/w-1.jpg"),
                name: 'ぽちゃクライム！',
                author: 'みんたろう'
              },
              {
                title: require("../static/images/rank/manga/w-2.jpg"),
                name: 'マカロン　アイドル百合アンソロジー',
                author: 'アンソロジー'
              },
              {
                title: require("../static/images/rank/manga/w-3.jpg"),
                name: '魔女が恋する5秒前',
                author: '澄谷ゼニコ'
              },
              {
                title: require("../static/images/rank/manga/w-4.jpg"),
                name: 'マッチングアプリ百合アンソロジー',
                author: 'アンソロジー'
              },
              {
                title: require("../static/images/rank/manga/w-5.jpg"),
                name: 'マーメイドライン 完全版',
                author: '金田一蓮十郎'
              },

            ],
          },
          {
            name: "编辑推荐",
            Manga: [{
                title: require("../static/images/rank/manga/t-1.jpg"),
                name: 'ゆりづくしの教室で',
                author: 'しーめ'
              },
              {
                title: require("../static/images/rank/manga/t-2.jpg"),
                name: 'ユリビュート 百合姫読切再録集',
                author: 'アンソロジー'
              },
              {
                title: require("../static/images/rank/manga/t-3.jpg"),
                name: 'ゆりゆり',
                author: 'なもり'
              },
              {
                title: require("../static/images/rank/manga/t-4.jpg"),
                name: 'ゆるゆりアンソロジー　10周年記念ver.',
                author: 'アンソロジー'
              },
              {
                title: require("../static/images/rank/manga/t-5.jpg"),
                name: 'ゆるゆり',
                author: 'なもり'
              },
            ],
          },
          {
            name: "最新更新",
            Manga: [{
                title: require("../static/images/rank/manga/q-1.jpg"),
                name: 'ゆるゆり資料集',
                author: 'ゆるゆり資料集編纂室'
              },
              {
                title: require("../static/images/rank/manga/q-2.jpg"),
                name: 'ゆるゆり10周年記念本　ゆるゆりX',
                author: '百合姫編集部・編'
              },
              {
                title: require("../static/images/rank/manga/q-3.jpg"),
                name: 'リフレクション！！',
                author: 'merryhachi'
              },
              {
                title: require("../static/images/rank/manga/q-4.jpg"),
                name: 'リリウム・テラリウム',
                author: 'ED'
              },
              {
                title: require("../static/images/rank/manga/q-5.jpg"),
                name: '凛としてカレンな花のように',
                author: 'ヒロアキ'
              },
            ],
          }
        ],
        nav: ['恋爱', '古风', '剧情'],
        typeList: ['悲剧类', '喜剧类', '剧情类'],
        workList: ['绘本', '条漫', '四格', '杂志', '合志'],
        noticeList: ['关于百合会网站与论坛之间账号绑定的说明', '百合会新手教程1.0版', '关于对小说站出现抄袭事件的说明'],
        lunboList: [
          require("../static/images/rank/manga/lunbo-1.jpg"),
          require("../static/images/rank/manga/lunbo-2.jpg"),
          require("../static/images/rank/manga/lunbo-3.jpg")
        ],
        acLunbo: 2,



        lueManga: [{
            title: require("../static/images/rank/manga/s-1.jpg"),
            name: '三日月のカルテ',
            author: '七坂なな'
          },
          {
            title: require("../static/images/rank/manga/s-2.jpg"),
            name: 'みらいのふうふですけど？',
            author: '野中友'
          },
          {
            title: require("../static/images/rank/manga/s-3.jpg"),
            name: 'メイドさんと百合についてのアンソロジー',
            author: 'アンソロジー'
          },
          {
            title: require("../static/images/rank/manga/s-4.jpg"),
            name: 'モデルちゃんと地味マネさん',
            author: 'たねこ'
          },
          {
            title: require("../static/images/rank/manga/s-5.jpg"),
            name: 'やわらかな命日',
            author: 'はにみ'
          },
        ]
      }
    },
    methods: {
      setIndex(index) {
        this.acLunbo = index
        this.$refs.lunbo.setActiveItem(index)
      }
    }
  }
</script>

<style lang="less" scoped="scoped">
  li,
  ul {
    list-style: none;
    margin: 0px;
  }

  * {
    box-sizing: border-box;
  }

  .content {
    margin: auto;
    margin-top: 60px;

    .contain {
      width: 1700px;
      margin: auto;

      // 顶部轮播结构
      .topBar {
        position: relative;
        width: 100%;
        height: 330px;
        background-color: #55ffff;
        margin-bottom: 100px;

        el-carousel-item {
          img {}
        }

        // 略缩图模式
        .loop_pagination {
          display: flex;
          align-items: center;
          position: absolute;
          z-index: 3;
          bottom: 20px;
          left: 50%;
          transform: translateX(-50%);
          width: 550px;
          height: 69px;
          background-color: rgba(0, 0, 0, 0.2);

          .loop_box {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;

            .loop-item {
              flex: 1;
              display: flex;
              align-items: center;
              justify-content: center;
              height: 65px;


              .img-contain {
                position: relative;
                height: 50px;
                width: 80%;
                background-color: #000000;
                overflow: hidden;

                img {
                  height: 100%;
                }

                &:hover {
                  border: 2px solid #fff;
                }

                &:hover span {
                  display: block;
                }

                span {
                  position: absolute;
                  display: block;
                  top: -18px;
                  left: 50%;
                  transform: translateX(-50%);
                  width: 0;
                  height: 0;
                  border-top: 8px solid transparent;
                  border-left: 8px solid transparent;
                  border-right: 8px solid transparent;
                  border-bottom: 8px solid #ffffff;
                  display: none;
                }
              }
            }
          }
        }

        .label-nav {
          height: 60px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          background-color: #333240;

          .label-list {
            display: flex;
            align-items: center;

            .nav {
              width: 50px;
              margin: 20px;
              text-align: center;
              color: #ffffff;
              font-size: 17px;
              cursor: pointer;
            }

            .nav-ac {
              font-weight: 600;
            }
          }

          .label-more {
            color: #fff;
            padding-right: 30px;
            cursor: pointer;
          }

        }
      }

      // 公告板块结构
      .notice {
        display: flex;
        align-items: center;
        justify-content: space-between;

        .notice-lt {
          width: 1200px;
          height: 300px;
          // background-color: rgba(42, 124, 255, 1.0);
          padding: 10px;
          border: solid 1px rgba(0, 0, 0, 0.1);

          .lt-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 15px;
          }

          .type-list {
            display: flex;
            align-items: center;

            .item {
              margin-right: 20px;
              cursor: pointer;

              &:hover {
                color: #ff5500;
              }
            }
          }
        }

        .notice-rt {
          width: 500px;
          height: 300px;
          padding: 10px;
          border: solid 1px rgba(0, 0, 0, 0.1);

          .rt-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 15px;
          }

          .notice-list {
            .notice-item {
              display: flex;
              align-items: center;
              width: 100%;
              height: 40px;
              padding-bottom: 4px;
              border-bottom: solid 1px #fff;
              cursor: pointer;
            }
          }
        }
      }

      // 热门漫画 推荐 结构
      .comic_list-hot {
        width: 1150px;
        box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);
        margin-top: 30px;
        padding: 4px 10px 0px 10px;

        .tit {
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: 60px;
          font-size: 30px;

          .tit-left {
            display: flex;
            align-items: center;
          }

          .tit-right {
            display: flex;
            align-items: center;
            font-size: 25px;
            margin-right: 20px;
            cursor: pointer;
          }

          .chose-ac {
            font-weight: 600;
            color: #fca713;
          }

          .chose {
            display: flex;
            align-items: center;
            margin-left: 30px;
            font-size: 17px;

            li {
              margin-right: 10px;
              cursor: pointer;
            }

            .type-ac {
              font-weight: 600;

              &::after {
                content: "";
              }
            }
          }
        }

        .list {
          display: flex;
          align-items: center;
          width: 100%;

          .item {
            width: 180px;
            height: 380px;
            margin-top: 5px;
            margin-right: 40px;
            transition: all .3s;

            &:hover {
              opacity: 0.8;
            }

            .item-top {
              height: 270px;
              // background-image: url(../static/see/manga/hot-1.jpg);
              background-size: auto 270px;
              background-position: center;
              background-repeat: no-repeat;
              box-shadow: 0 0 20px 0 rgb(0 0 0 / 20%);

              img {
                height: 100%;
              }
            }

            .item-bottom {
              padding: 6px;

              .bottom-name {
                font-size: 20px;
                font-weight: 600;
                margin-bottom: 5px;
                overflow: hidden;

                text-overflow: ellipsis;

                white-space: nowrap;
              }

              .bottom-writer {
                font-size: 13px;
                margin-bottom: 5px;
              }

              .bottom-desc {
                font-size: 13px;
                color: #606266;
              }
            }
          }
        }
      }

      .manga-main {
        display: flex;
        justify-content: space-between;
      }

      // 排行榜
      .rank {
        width: 500px;
        height: 1000px;
        margin-top: 30px;
        padding: 10px;
        box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);

        .rank-1 {
          .title {
            font-size: 30px;
            // font-weight: 600;
          }

          .list {

            .item {
              display: flex;
              justify-content: space-between;
              height: 50px;
              align-items: center;
              padding: 0 10px;
              cursor: default;

              .item-lt {
                span {
                  color: #ff5500;
                  margin-right: 10px;
                }


              }

              .item-rt {
                color: #909399;

                span {
                  color: #ff5500;

                  &:hover {
                    cursor: pointer;
                    text-decoration: underline;
                  }
                }
              }
            }


            .item-ac {
              display: none;

              &:hover+item {
                display: none;
              }

              .ac-contain {
                display: flex;
              }

              .item-lt {
                position: relative;
                width: 120px;
                height: 160px;

                img {
                  height: 100%;
                }

                .index {
                  position: absolute;
                  left: 0px;
                  top: 0px;
                  padding: 4px 8px;
                  background-color: #409EFF;
                }
              }

              .item-rt {
                width: 300px;
                height: 160px;
                margin-left: 10px;

                &:hover {}

                .name {
                  font-size: 23px;
                  margin-bottom: 8px;
                }

                .labels {
                  display: flex;
                  margin-bottom: 8px;

                  .label {
                    margin-right: 5px;
                    font-size: 15px;
                  }
                }

                .desc {
                  height: 50px;
                  display: -webkit-box;
                  -webkit-box-orient: vertical;
                  -webkit-line-clamp: 2; // 根据实际情况修改
                  overflow: hidden;
                  text-overflow: ellipsis;
                  padding-right: 10px;
                  line-height: 25px;
                  font-size: 16px;
                  color: #606266;
                }

                .latest {
                  color: #606266;

                  span {
                    color: #F56C6C;

                    &:hover {
                      cursor: pointer;
                      text-decoration: underline;
                    }
                  }
                }
              }
            }

            .item:hover+.item-ac {
              display: block;
            }
          }

        }
      }
    }
  }
</style>
