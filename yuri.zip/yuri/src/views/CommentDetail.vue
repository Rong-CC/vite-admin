<template>
  <div class="content">
    <div class="conment">
      <div class="post-mation">
        <div class="lt">
          <div>
            查看：<span>3458</span>
          </div>
          <div>
            回复：<span>69</span>
          </div>
        </div>
        <div class="rt">
          关于网站
        </div>
      </div>
      <div class="list">
        <div class="item" v-for="(item,index) in post" :key="index">
          <div class="lt">
            <div class="name">
              {{item.name}}
            </div>
            <div class="headIMG">
              <img :src="item.imgURL" />
            </div>
            <div class="data">
              <div class="data-1" v-for="(item,index) in dataList">
                <div class="data-num">
                  {{item.num}}
                </div>
                <div class="data-name">
                  {{item.name}}
                </div>
              </div>
            </div>

            <div class="uid">
              <span>
                uid
              </span>
              <span>
                {{item.uid}}
              </span>
            </div>

            <div class="position">
              花蕾
            </div>
            <div class="chet">
              <i class="el-icon-chat-round"></i>
              <span>
                私聊
              </span>
            </div>
          </div>
          <div class="rt">
            <div class="row-1">
              <i class="el-icon-male"></i>
              &nbsp;&nbsp;
              发表于&nbsp;&nbsp;
              <span>{{item.time}}</span>
              | &nbsp;&nbsp;&nbsp;&nbsp;
              <span>
                只看该作者
                <i class="el-icon-caret-right">
                </i>
              </span>
            </div>
            <div class="conment-content">
              {{item.ctent}}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        post: [
          {
            name:"singull",
            uid:"393174",
            imgURL:require("../static/images/forum/head-1.jpg"),
            ctent: `在某位贴吧吧友的推荐下找到了这部漫，可以说是继里世界郊游后第二部让我一边在半夜看得瑟瑟发抖但是又上头的惊悚百合漫了，漫画已经在韩网连载近2年，最近登录了b漫正版化，
                    惊觉居然在此之前没有专门的帖子安利过这部，我便来补充一下这个空白了。
                    世界观中可以看到scp+克苏鲁的呼唤+圣经犹太教的影子。主角之一阿勒菲是来自“天庭”的高位生物（天使），自称“第一种植园主”，
                    为了交到人类“朋友”而降临到物质界，偶然邂逅了另一位主角茹美。`,
            time:"2022-4-27 0：49"
          },
          {
            name:"在下洛三岁",
            uid:"374373",
            imgURL:require("../static/images/forum/head-2.jpg"),
            ctent: `
                    终将44话刚出时（大概是凌晨），在微博刷到图后兴奋到睡不着觉，直接熬到了早上，顺便又重刷了一遍叛逆的物语（索性那天是周日）

                    seabed通关后（大概也是凌晨几点）哭的不能自己，在网上翻了半天把寥寥无几的相关讨论全看了一遍（又熬了通宵），看到有人吹seabed就特别开心，庆幸自己遇到了这么好的作品（结果很快就被“安利不出去/找不到能讨论的人”的现实打击到了）

                    以前追了b站很火的一对游戏up，一边揉着笑僵的脸一边刷相关视频，还用半个小时向直女朋友传教（然而一年后我亲手整理了两人的所有相关视频和微博（还有出事的过程），用来纪念（记录）我真情实感磕的第一对女同cp，令人感叹）`,
            time:" 2022-6-6 00:37"
          },
          {
            name:"bernkastel",
            uid:"372978",
            imgURL:require("../static/images/forum/head-3.jpg"),
            ctent: `
                    不知道算不算 但是一開始看一些輕百合(友情向)覺得有一起奮鬥的朋友真好
                    加上因為一些經歷所以高中開始有點不喜歡男生 (不下流 不說黃色笑話的例外 但高中男生基本都那樣

                    在學校被女生告白三四次左右 開始好奇真百合是怎麼運作的
                    期間甚至發現班上有個朋友在吃我跟同學的貼貼cp
                    發現自己根本百合天選之人主人公 不知不覺也變成百合

                    現在每天都看百合 覺得人生都套上粉嫩濾鏡
                    恩 果然 女孩子一起的 純潔的感覺 香香的世界真是美麗`,
            time:"发表于 2022-6-6 01:24 "
          }
        ],
        dataList: [{
            name: "帖子",
            num: 123
          },
          {
            name: "积分",
            num: 223
          },
          {
            name: "精华",
            num: 1456
          }
        ]
      }
    }
  }
</script>

<style lang="less" scoped="scoped">
  * {
    box-sizing: border-box;
  }

  .content {
    width: 1700px;
    margin: auto;
    margin-top: 80px;
    box-shadow: 0 1px 3px rgb(18 18 18 / 10%);

    .conment {
      .post-mation {
        display: flex;
        align-items: center;
        border-bottom: solid 1px #606266;

        .lt {
          display: flex;
          justify-content: space-between;
          width: 241px;
          padding: 20px;
          border-right: solid 1px #909399;

          span {
            color: #409EFF;
          }
        }

        .rt {
          padding: 10px 20px;
          font-size: 25px;
          font-weight: 600;
        }
      }

      .list {
        .item {
          display: flex;
          border-bottom: solid 1px #909399;

          .lt {
            width: 250px;
            padding: 20px;
            border-right: solid 1px #909399;

            .name {
              font-size: 20px;
              font-weight: 600;
              padding-bottom: 8px;
              border-bottom: solid 1px #909399;
              margin-bottom: 10px;
            }

            .headIMG {
              width: 200px;
              height: 200px;
              background-color: #409EFF;
              margin-bottom: 10px;

              img {
                width: 100%;
                height: 100%;
              }
            }

            .data {
              display: flex;
              margin-bottom: 20px;

              .data-1 {
                flex: 1;
                text-align: center;

                .data-num {
                  margin-bottom: 3px;
                }

                .data-name {
                  color: #606266;
                }
              }
            }

            .uid {
              display: flex;
              justify-content: space-between;
              font-size: 20px;
              margin-bottom: 10px;
            }

            .position {
              margin-bottom: 10px;
            }

            .chet {
              cursor: pointer;
            }
          }

          .rt {
            padding-left: 20px;

            .row-1 {
              display: flex;
              align-items: center;
              height: 50px;
              border-bottom: solid 1px #909399;
              margin-bottom: 20px;

              span {
                margin-right: 20px;
              }
            }

            .conment-content {
              line-height: 2.0;
            }
          }
        }
      }
    }
  }
</style>
