<template>
  <!-- 登录页面 -->
  <div class="content">
    <div class="desc-txt" v-show="false">
      <div class="title">
        百合会
      </div>
      <div class="desc">
        用心 - 打造社区
      </div>
    </div>
    <div class="land" v-show="false">
      <div class="title">
        登录
      </div>
      <div class="inpt">
        <el-input placeholder="请输入内容" prefix-icon="el-icon-user" v-model="userName">
        </el-input>
      </div>
      <div class="inpt">
        <el-input placeholder="请输入内容" prefix-icon="el-icon-lock" v-model="password">
        </el-input>
      </div>
      <div class="btn-land">
        <el-button type="primary">登录</el-button>
      </div>
      <div class="register-bar">
        <span>
          遇到问题
        </span>
        <span>
          立即注册
        </span>
      </div>
    </div>
    <div class="regist">
      <div class="lt">
        <div class="cions">
          <!-- 网站图标 -->
          <img src="../static/images/facon.png" >
        </div>
        <div class="title">
          百合会
        </div>
        <div class="desc">
          ゆりかいぼとなけしんあ
        </div>
        <div class="www">
          www.baihehui.com
        </div>
      </div>
      <div class="rt">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="登录" name="first">

            <div class="title">
              Login
            </div>
            <div class="desc">
              欢迎来到百合会
            </div>
            <div class="inpt">
              <div class="name">User Name</div>
              <input type="" name="" id="" value="" />
            </div>
            <div class="inpt">
              <div class="name">Paasword</div>
              <input type="" name="" id="" value="" />
            </div>
            <div class="remeber">
              <div class="rb-lt">
                <el-checkbox v-model="checked">记住账户密码</el-checkbox>
              </div>
              <div class="rb-rt">
                忘记密码？
              </div>
            </div>
            <div class="btn">
              <el-button type="primary">登录</el-button>
            </div>
          </el-tab-pane>
          <el-tab-pane label="注册" name="second">
            <div class="title">
              Regist
            </div>
            <div class="desc">
              欢迎注册百合会，成为我们的一员
            </div>
            <div class="inpt">
              <div class="name">用户名</div>
              <input type="" name="" id="" value="" />
            </div>
            <div class="inpt">
              <div class="name">用户密码</div>
              <input type="" name="" id="" value="" />
            </div>
            <div class="inpt">
              <div class="name">请再次输入密码</div>
              <input type="" name="" id="" value="" />
            </div>
            <!-- <div class="remeber">
              <div class="rb-lt">
                <el-checkbox v-model="checked">记住账户密码</el-checkbox>
              </div>
              <div class="rb-rt">
                忘记密码？
              </div>
            </div> -->
            <div class="btn">
              <el-button type="primary">注册</el-button>
            </div>
          </el-tab-pane>
        </el-tabs>


      </div>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        userName: '',
        password: '',
        checked: false,
         activeName: 'first'
      }
    }
  }
</script>

<style lang="less" scoped="scoped">
  * {
    text-align: left;
    box-sizing: border-box;
  }

  .content {
    width: 100%;
    height: 100%;

    .desc-txt {
      position: absolute;
      left: 200px;
      top: 100px;

      .title {
        font-size: 60px;
        font-weight: 600;
        margin-bottom: 10px;
      }

      .desc {
        font-size: 30px;
        font-weight: 600;

      }
    }

    .land {
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translateY(-50%) translateX(-50%);
      padding: 30px 50px;
      box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);

      .title {
        font-size: 30px;
        font-weight: 600;
        margin-bottom: 50px;
      }

      .inpt {
        width: 300px;
        margin-bottom: 15px;

        .el-input__inner {
          height: 60px;
        }
      }

      .el-button {
        margin-top: 50px;
        height: 50px;
        width: 100%;
        font-size: 17px;
      }

      .register-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;

        span {
          color: #4ea4dc;
          cursor: pointer;
        }
      }
    }

    .regist {
      position: absolute;
      z-index: 40;
      width: 1360px;
      height: 860px;
      left: 50%;
      top: 50%;
      transform: translateY(-50%) translateX(-50%);
      display: flex;
      box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);

      .lt {
        width: 680px;
        height: 100%;
        padding-left: 80px;
        // background-image:url(../static/images/land.png);
        .cions{
          margin-top: 30px;
          img{
            width: 60px;
            height: 60px;
          }
        }
        .title {
          font-size: 60px;
          font-weight: 600;
          color: #FFFFFF;
          margin-top: 170px;
          margin-bottom: 30px;

        }

        .desc {
          font-size: 16px;
          color: #FFFFFF;
        }

        .www {
          margin-top: 350px;
          color: #FFFFFF;
        }
      }

      .rt {
        width: 680px;
        height: 100%;
        padding: 120px 85px;

        .title {
          font-size: 35px;
          margin-bottom: 25px;
        }

        .desc {
          color: #b3b3b3;
          margin-bottom: 40px;

        }

        .inpt {
          margin-bottom: 40px;

          .name {
            font-size: 13px;
            color: #b3b3b3;
            margin-bottom: 15px;
          }

          input {
            outline: none;
            background-color: #fff;
            background-image: none;
            border-radius: 4px;
            border: 1px solid #dcdfe6;
            box-sizing: border-box;
            color: #606266;
            display: inline-block;
            font-size: inherit;
            line-height: 40px;
            padding: 0 15px;
            transition: border-color .2s cubic-bezier(.645, .045, .355, 1);
            width: 425px;
            height: 55px;
          }

          input:focus {
            outline: none;
            border-color: #409eff;
          }
        }

        .remeber {
          display: flex;
          justify-content: space-between;
          align-items: center;
          width: 425px;
          margin-bottom: 30px;

          .rb-lt {}

          .rb-rt {
            color: #b3b3b3;
          }
        }

        .btn {
          width: 425px;
          text-align: center;
          .el-button {
            width: 100%;
            height: 66px;
            font-size: 25px;
          }
        }
      }

    }
  }
</style>
