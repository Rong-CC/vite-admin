<template>
  <div class="main">
    <!-- 大轮播图，网站特色 -->
    <div class="top-show">
      <div class="show-contain">
        <el-select v-model="value" placeholder="请选择">
          <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
        <div class="search">
          <el-input placeholder="请输入搜索内容" prefix-icon="el-icon-search" v-model="input2">
          </el-input>
        </div>
      </div>
    </div>
    <!-- 论坛板块快速导航 -->
    <div class="nav-list">
      <div class="nav-item" v-for="(item,index) in labels" :key="index">
        {{item.name}}
      </div>
    </div>
    <!-- 每日介绍 -->
    <div class="row-1">
      <div class="left">
        <el-carousel trigger="click" height="400px">
          <el-carousel-item v-for="(item,index) in imglist1" :key="index">
            <img :src="item">
          </el-carousel-item>
        </el-carousel>
      </div>
      <div class="right">
        <div class="change">
          <el-button>
            换一换
          </el-button>
        </div>
        <div class="post-list">
          <div class="post-item" v-for="(item,index) in hotList" :key='index'>
            <div class="post-row">
              <div class="title">
                {{item}}
              </div>
              <div class="push-time">
                2022-5-30 00:15
              </div>
            </div>
            <div class="desc">
              发布人：欺世良
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 论坛主要入口 -->
    <div class="forums">
      <div class="forum-item" v-for="(item,index) in mode" :key="index" @click="toForum">
        <div class="top">
          <img :src="item.imc">
        </div>
        <div class="bottom">
          <div class="title">
            {{item.name}}
          </div>
          <div class="desc">
            {{item.desc}}
          </div>
          <el-divider content-position="left"></el-divider>
          <div class="to">
            <div>
              进入板块
              <i class="el-icon-right"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      activeIndex: '1',
      activeIndex2: '1',
      hotList: [
        '大家都有哪些关于百合的快乐的记忆？',
        '国产百合游戏卫星',
        '《LOL》曙光&皎月新故事“同我上升”百合',
        '隔壁宿舍的四川小美女居然有一个女朋友，但',
        ' 大家心里第一的韩漫是什么？',
        ' 我推是反派大小姐。（私の推しは悪役令嬢。）安利&信息汇总&公开讨论 '
      ],
      imglist1: [
        // require('@/static/images/index/lunbo-1.jpg'),
        // require('@/static/images/index/lunbo-2.png'),
        // require('@/static/images/index/lunbo-3.jpg'),
        // require('@/static/images/index/lunbo-4.jpg')
      ],
      imglist2: [
        // require('../../static/images/index/bank-1.png'),
        // require('../../static/images/index/bank-2.png'),
        // require('../../static/images/index/bank-3.jpg'),
        // require('../../static/images/index/bank-4.jpg')
      ],
      list1: ['游戏创作', '小说创作', '漫画创作', '程序员交流会'],
      input2: '',
      value: '帖子',
      options: [{
        value: '选项1',
        label: '用户'
      }, {
        value: '选项2',
        label: '专题'
      }, {
        value: '选项3',
        label: '漫画'
      }, {
        value: '选项4',
        label: '小说'
      }, {
        value: '选项5',
        label: '动漫'
      }],
      mode: [{
        name: '管理板块',
        // imc: require('@/static/images/index/bank-1.png'),
        desc: '既无论先民后主，何必辩你们我们。'

      },
      {
        name: '动漫板块',
        // imc: require('@/static/images/index/bank-2.jpg'),
        desc: '请不要在莉莉安女子学院里狂奔……你给我站住！！'

      },
      {
        name: '小说板块',
        // imc: require('@/static/images/index/bank-3.jpg'),
        desc: '天方夜谭'
      },
      {
        name: '漫画板块',
        // imc: require('@/static/images/index/bank-4.jpg'),
        desc: '游戏人间'
      }
      ],
      labels: [
        {
          name: '八卦杂谈'
        },
        {
          name: '情感树洞'
        },
        {
          name: '理性讨论'
        },
        {
          name: '新闻咨询'
        },
        {
          name: '电脑数码'
        },
        {
          name: '互相安利'
        },
        {
          name: '影音殿堂'
        }
      ]
    }
  },
  props: {
    msg: String
  },
  methods: {
    handleSelect () {

    },
    // 跳转论坛
    toForum () {
      this.$router.push('/Forum')
    }
  }
}
</script>

<style lang="less" scoped="scoped">
  .main {
    // min-height: 1000px;
    width: 100%;
    max-width: 2270px;
    padding: 0px 130px;
    margin: auto;
    margin-top: 60px;

    .top-show {
      position: relative;
      height: 450px;
      background-color: #ffaa7f;
      // background-image: url(../static/images/index/banner.jpg);
      background-size: 100%;
      background-position: center;

      .show-contain {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translateY(-50%) translateX(-50%);
        display: flex;

        .el-select {
          width: 100px;
        }

        .search {
          width: 600px;
        }
      }

      // background-image: ;

    }

    .nav-list {
      display: flex;
      flex-wrap: wrap;
      max-width: 1200px;
      margin: 40px 0;

      .nav-item {
        padding: 8px 30px;
        border-radius: 6px;
        background-color: rgba(242, 243, 244, 1.0);
        margin-right: 20px;
        margin-bottom: 20px;
        cursor: pointer;
      }
    }

    .row-1 {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 40px;

      .left {
        width: 40%;
        height: 400px;
        background-color: #6ec1e7;

        img {
          width: 100%;
          height: auto;
        }
      }

      .right {
        position: relative;
        width: 58%;
        height: 400px;

        .change {
          position: absolute;
          right: -70px;

          .el-button {
            box-sizing: content-box;
            width: 17px;
            height: 80px;
            padding: 0px 15px;
            background-color: #fff;
            border: 1px solid #E3E5E7;
            border-radius: 8px;
            white-space: normal;
            // writing-mode: vertical-lr;
          }
        }

        .post-list {
          height: 400px;
          overflow: hidden;
          .post-item {
            background-color: rgba(255, 255, 255, 1.0);
            padding: 5px 20px;
            box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);
            border-radius: 5px;
            margin-bottom: 17px;

            .post-row {
              display: flex;
              align-items: center;
              justify-content: space-between;
              margin-bottom: 3px;

              .title {
                font-size: 17px;
              }

              .push-time {
                font-family: '幼圆';
              }
            }

            .desc {
              font-size: 13px;
              color: #606266;
            }
          }
        }
      }
    }

    .forums {
      display: flex;
      align-items: center;
      justify-content: space-between;

      .forum-item {
        width: 300px;
        height: 300px;
        background-color: #fff;
        cursor: pointer;
        border: 1px solid rgba(0,0,0,0.1);
        .top {
          height: 150px;
          overflow: hidden;
          background-color: #073650;

          img {
            position: relative;
            top: -30px;
            width: 100%;
            height: auto;
            background-color: #50bdeb;
          }
        }

        .bottom {
          height: 150px;
          padding: 10px 20px;

          .title {
            font-size: 17px;
            font-weight: 600;
            margin-bottom: 10px;
          }

          .desc {
            height: 50px;
            font-size: 13px;
            color: #606266;
          }

          .el-divider--horizontal {
            margin: 5px;
            margin-bottom: 10px;
          }

          .to {
            display: flex;
            justify-content: flex-end;
          }

        }
      }
    }
  }
</style>
