<template>
  <div class="content">
    <el-container>
      <el-header>
        <div class="contain">
          <div class="contain-left">
            <!-- <img src="@/static/images/facon.png"> -->
            <span>百合会</span>
            <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" @select="handleSelect">
              <el-menu-item index="1" @click='toPage("Index")'   >首页</el-menu-item>
              <el-submenu index="2">
                <template slot="title">更多</template>
                <el-menu-item index="2-1">官方微博1</el-menu-item>
                <el-menu-item index="2-2">BLOG</el-menu-item>
                <el-menu-item index="2-3">群组</el-menu-item>
                <el-menu-item index="2-3">繁简切换</el-menu-item>
              </el-submenu>
              <el-menu-item index="3" @click='toPage("Leaderboard")'>排行榜</el-menu-item>
              <el-menu-item index="4" @click='toPage("Manga")'>漫画站</el-menu-item>
              <el-menu-item index="5" @click='toPage("Land")'>我的收藏</el-menu-item>
            </el-menu>
          </div>
          <div class="contain-right">
            <!-- 本站更多应用 -->
            <div class="more">
              <!-- <el-dropdown>
                <span class="el-dropdown-link">
                  <i class="el-icon-s-grid"></i>
                </span>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>黄金糕</el-dropdown-item>
                  <el-dropdown-item>狮子头</el-dropdown-item>
                  <el-dropdown-item>螺蛳粉</el-dropdown-item>
                  <el-dropdown-item disabled>双皮奶</el-dropdown-item>
                  <el-dropdown-item divided>蚵仔煎</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown> -->
            </div>
            <div class="user">
              <el-dropdown trigger="click">
                <span class="el-dropdown-link">
                  <div class="user-contain">
                    <div class="headImg">
                      <!-- <img src="@/assets/logo.png"> -->
                    </div>
                    <div class="user-name">
                      欺世良
                    </div>
                    <i class="el-icon-arrow-down"></i>
                  </div>
                </span>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>
                    <div class="panel-header">

                      <!-- <img class="panel-avatar" src="@/assets/logo.png"> -->
                      <div class="panel-name">欺世良</div>
                      <div class="panel-tenant">知趣体验版</div>
                    </div>
                  </el-dropdown-item>
                  <el-dropdown-item>
                    <div class="panel-tab1">
                      <span>
                        切换账号
                      </span>
                      <i class="el-icon-arrow-right"></i>
                    </div>
                  </el-dropdown-item>
                  <el-dropdown-item>
                    <div class="panel-tab1" @click="toPage('Land')">
                      退出登录
                    </div>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </div>
            <div class="dowload">
              <el-button type="primary">下载软件</el-button>
            </div>
          </div>
        </div>
      </el-header>
      <router-view></router-view>
    </el-container>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      activeIndex: '1',
      activeIndex2: '1',
      list1: ['游戏创作', '小说创作', '漫画创作', '程序员交流会'],
      input2: '',
      value: '帖子',
      options: [{
        value: '选项1',
        label: '用户'
      }, {
        value: '选项2',
        label: '专题'
      }, {
        value: '选项3',
        label: '漫画'
      }, {
        value: '选项4',
        label: '小说'
      }, {
        value: '选项5',
        label: '动漫'
      }],
      mode: ['管理板块', '动漫板块', '小说板块', '漫画板块']
    }
  },
  props: {
    msg: String
  },
  methods: {
    handleSelect () {

    },
    // 跳转论坛
    toForum () {
      this.$router.push('/Forum')
    },
    // 跳转其它页面:1.排行榜
    toPage (e) {
      this.$router.push('/' + e)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less" scoped>
  @black: rgba(0, 0, 0, 1);
  @long: 30px;
  @naka: 20px;
  @short: 10px;
  body{
    padding: 0px;
  }
  .content {
    padding: 0px;
    .el-header {
      position: fixed;
      top: 0px;
      z-index: 20;
      width: 100%;
      background-color: #fff;
      box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);
    }

    .contain {
      padding: 0px 110px;
      margin: auto;
      display: flex;
      align-items: center;
      justify-content: space-between;

      .contain-left {
        display: flex;
        align-items: center;

        img {
          width: 50px;
          height: 50px;
          margin-right: 20px;
        }

        span {
          font-size: 40px;
          font-weight: 600;
          font-family: '叶根友特色简体升级版';
          margin-right: 30px;
        }
      }

      .panel-header {
        width: 200px;
        background-color: #2C3E50;
      }

      .contain-right {
        display: flex;
        align-items: center;

        .more {
          margin-right: @long;
        }

        .user {
          margin-right: @long;

          .user-contain {
            display: flex;
            align-items: center;

            .headImg {
              width: 50px;
              height: 50px;
              background-color: #2C3E50;
              margin-right: @naka;
              border-radius: 50%;
              overflow: hidden;

              img {
                width: 50px;
                height: 50px;
              }
            }
          }
        }
      }
    }
  }

  .el-dropdown-menu {
    padding: 0px;
  }

  .el-dropdown-menu__item {
    padding: 0px;
  }

  .panel-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 200px;
    padding: 8px;

    img {
      width: 50px;
      height: 50px;
      border-radius: 50%;
    }

  }

  .panel-tab1 {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: solid 0.5px rgba(0, 0, 0, 0.3);
    padding: 6px 10px;
  }

  * {
    box-sizing: border-box;
    text-align: left;
  }
</style>
