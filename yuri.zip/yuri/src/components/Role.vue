<template>
  <div class="content">
    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane label="每周热度" name="first">
        <div class="left">
          <div class="role-list">
            <div @click="changeIndex(index)" class="role-item" :class="{'ac-role-item' : index==acIndex}"
              v-for="(item,index) in roleList" :key="index">
              <div class="role-idx">
                0{{index}}
              </div>
              <div class="role-career">
                <i class="el-icon-s-tools"></i>
              </div>
              <div class="role-name">
                {{item.name}}
              </div>
            </div>
          </div>
        </div>
        <div class="right">
          <div class="role-card">
            <div class="card-contain">
              <img :src="roleList[acIndex].imgUrl">
              <!-- 海报文字报幕 -->
              <div class="img-action">
                <div class="action">
                  <div class="personality">
                    <span>二型人格</span>
                    <i>personality</i>
                  </div>
                  <div class="title">
                    {{roleList[acIndex].name}}
                  </div>
                  <div class="logo">
                    <!-- <img :src="roleList[acIndex].imgUrl"> -->
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="role-desc">
            <div class="desc-img">
              <!-- <img :src="roleList[acIndex].imgUrl"> -->
            </div>
            <div class="desc-txt">
              <div class="desc-title">
                <div class="top">
                  {{roleList[acIndex].name}}
                </div>
                <div class="bottom">
                  <div class="btm-lt">
                    {{roleList[acIndex].Ename}}
                    <!-- 负责背景的映射 -->
                    <div class="btm-lt-bc">
                      {{roleList[acIndex].Ename}}
                    </div>
                  </div>
                  <div class="btm-rt">
                    <span>
                      <!-- cv：黑泽彭氏 -->
                    </span>
                    <!-- <i class="el-icon-goods"></i> -->
                  </div>
                </div>
              </div>
              <div class="desc-intro">
                {{roleList[acIndex].desc}}
              </div>
            </div>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="每月热度" name="second"></el-tab-pane>
      <el-tab-pane label="每年热度" name="third"></el-tab-pane>
      <el-tab-pane label="新热" name="fourth"></el-tab-pane>
    </el-tabs>

  </div>
</template>

<script>
  export default {
    data() {
      return {
        activeName: 'first',
        acIndex: 0,
        roleList: [{
            name: "紫阳花",
            Ename: "アジサイ",
            imgUrl: require('../static/images/rank/roles/r-1.jpg'),
            desc: `グループのバランサー。
                    癒やしの笑顔とほんわかオーラを ス
                    使いこなす大天使。明るく優しく、誰とでも く
                    別け隔てなく付き合っている。
                    メンバーの仰を自然に取り持ってしまうほどに、
                    懐が深い。小さな弟がふたりいるため、
                    家ではお姉ちゃんとしてもがんばっている。`,
          },
          {
            name: "七海灯子",
            Ename: "ななみ　とうこ",
            imgUrl: require('../static/images/rank/roles/r-2.jpg'),
            desc: "”好き”は束縛する言葉。（喜欢，是束缚的言语。）だから、好きを持たない君が、（所以，不会喜欢别人的你，",
          },
          {
            name: "佐伯沙弥香",
            Ename: "さえき さやか",
            imgUrl: require('../static/images/rank/roles/r-3.jpg'),
            desc: `这样就好，只要继续如此，只要她还如此保持下去，在这期间，我都会是离她最近的那个人。
                  关系这么好啊，和小糸同学···有点嫉妒呢
                  灯子对谁都很亲切，也给人一种很容易亲近的印象。但实际上，超过一定的距离，她就绝对不会再让你接近了。`,
          },
          {
            name: "小糸侑",
            Ename: "こいと　ゆう",
            imgUrl: require('../static/images/rank/roles/r-4.jpg'),
            desc: "少女漫画，和情歌的歌词，）私には、キラキラとまぶしくて。（在我眼里，是那么耀眼夺目。）でも、どうしても、届かなくて。",
          },
          {
            name: "安达樱",
            Ename: "あだち",
            imgUrl: require('../static/images/rank/roles/r-5.jpg'),
            desc: "主角。天秤座。时常在上课时间翘课，是老师和学生公认的不良少女。某次在体育馆二楼翘课结识了岛村。个性冷静且沉着，唯独面对岛村时会展现少女的一面。经常为了如何接近岛村而烦恼。常过度紧张或兴奋导致奇怪的行为（下意识追寻岛村、过度紧张到全身僵硬得像木偶等），被岛村认为像犬类。高二分班后与岛村同班。",
          }
        ]
      }
    },
    methods: {
      handleClick(tab, event) {
        console.log(tab, event);
      },
      changeIndex(index) {
        this.acIndex = index
      }

    }
  }
</script>

<style lang="less" scoped="scoped">
  * {
    box-sizing: border-box;
  }

  .content {
    background-color: #ffffff;
    margin-top: 0px;

    .el-tab-pane {
      display: flex;
      justify-content: space-between;
    }

    .left {
      width: 300px;
      height: 100%;
      padding: 30px 0px 0px 20px;

      .role-list {

        .role-item {
          display: flex;
          align-items: center;
          margin-bottom: 20px;
          cursor: pointer;
          transition: all .4s;
          opacity: 0.8;

          &:hover {
            opacity: 1.0;
          }

          .role-idx {
            margin-right: 10px;
          }

          .role-career {
            margin-right: 10px;

            i {
              transition: all .2s;
              font-size: 35px;
            }
          }

          .role-name {
            font-size: 25px;
            // font-size: 30px;
            font-weight: 600;
            font-family: '黑体';
            color: rgba(0, 0, 0, 1.0);
          }
        }

        .ac-role-item {
          color: #55aaff;
          opacity: 1.0;
          transition: all .8s;

          .role-idx {
            font-size: 15px;
          }

          .role-career {
            i {
              font-size: 40px;
            }
          }

          .role-name {
            font-size: 30px;
            // font-size: 30px;
            color: rgba(85, 170, 255, 1.0);
          }
        }
      }
    }

    .right {
      display: flex;
      width: 1350px;
      height: 100%;

      .role-card {
        display: flex;
        align-items: center;
        width: 530px;
        height: 870px;
        // background-color: #54d426;


        .card-contain {
          position: relative;
          width: 400px;
          max-width: 700px;
          background-color: #fff;
          // background-image: url(../static/Role/role-1.png);
          background-repeat: no-repeat;
          background-size: auto 100%;
          background-position: center;
          margin: auto;
          border: 4px solid #fff;
          box-shadow: rgba(0, 0, 0, 0.1) 0px 2px 12px 0px;
          overflow: hidden;
          img{
            width: 100%;
          }
          // box-shadow: ;
          .img-action {
            transition: all .3s;

            &:hover {
              opacity: 0.2;
            }

            position: absolute;
            top: 0px;
            width: 100%;
            height: 100%;
            // background-color: linear-gradient(#fff,#6bff84);
            background-image: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.6));

            .action {
              position: absolute;
              bottom: 10px;
              width: 100%;
              height: 160px;
              text-align: center;

              .personality {
                box-sizing: content-box;
                font-size: 18px;
                color: #ffffff;

                span {
                  margin-right: 10px;
                  font-family: '黑体';
                }

                i {
                  font-size: 12px;
                  font-family: '黑体';
                }
              }

              .title {
                margin: auto;
                color: #ffffff;
                font-size: 30px;
                font-weight: 600;
                font-family: '黑体';
                margin-bottom: 20px;
              }

              .logo {
                img {
                  width: 80px;

                }
              }
            }
          }
        }
      }

      // 角色介绍
      .role-desc {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        width: 530px;
        height: 870px;

        // 角色相关图片
        .desc-img {
          width: 530px;
          height: 420px;
          background-color: rgba(255, 255, 255, 1.0);
          box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);
          padding: 10px;
          // 设置海报报幕

          img {
            width: 100%;
            height: 100%;
          }
        }

        // 角色文字介绍
        .desc-txt {
          position: relative;
          width: 530px;
          height: 400px;
          background-color: #ffffff;
          color: #000000;
          padding: 15px;

          &::before {
            content: "";
            display: block;
            position: absolute;
            left: -20%;
            top: 134px;
            background-image: linear-gradient(to right, rgba(255, 255, 255, 0) 0%, rgba(95, 95, 95, 0.5) 20%, rgba(147, 147, 147, 0.5) 80%, rgba(255, 255, 255, 0) 100%);
            width: 120%;
            height: 1px;
            opacity: 1.0;
            transition: width 0.3s 0.1s, opacity 0.3s 0.1s;
          }

          &::after {
            content: "";
            display: block;
            position: absolute;
            background-image: linear-gradient(to bottom, rgba(255, 255, 255, 0) 0%, rgba(95, 95, 95, 0.5) 20%, rgba(147, 147, 147, 0.5) 80%, rgba(255, 255, 255, 0) 100%);
            width: 1px;
            height: 120%;
            top: 0;
            left: 0;
            transition: height 0.3s, opacity 0.3s;
          }

          .desc-title {
            padding-left: 20px;
            padding-bottom: 20px;

            .top {
              margin-bottom: 10px;
              font-size: 55px;
              font-family: '黑体';
              font-weight: 600;
            }

            .bottom {
              display: flex;
              justify-content: space-between;

              .btm-lt {
                position: relative;
                font-weight: 600;
                letter-spacing: 3px;

                .btm-lt-bc {
                  position: absolute;
                  left: -30px;
                  top: -8px;
                  font-family: 'Geometos';
                  color: rgba(129, 129, 129, 0.4);
                  font-size: 45px;
                }
              }
            }

          }

          .desc-intro {
            padding-top: 30px;
            padding-left: 30px;
            font-size: 13px;
            line-height: 2.0;
            p {
              margin-bottom: 20px;
            }
          }
        }

      }
    }
  }
</style>
