<template>
  <div class="content">
    <div class="list">
      <div class="title">
        <span class="name">
          <!-- NEW COMICS -->
          新作预览
        </span>
        <span class="desc">
          日系新作
        </span>
      </div>
      <div class="list-contain">
        <div class="item" v-for="(item,index) in mangaList" :key="index">
          <div class="top">
            <img :src="item.title">
          </div>
          <div class="bottom">
            <div class="name">
              {{item.name}}
            </div>
            <div class="desc">
              {{item.status}}
            </div>
            <div class="time">
              {{item.author}}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        mangaList: [{
            title: require("../static/images/rank/manga/m-1.jpg"),
            name: '夏とレモンとオーバーレイ',
            author: '漫画：宮原都　原作：Ru'
          },
          {
            title: require("../static/images/rank/manga/m-2.jpg"),
            name: '今日もひとつ屋根の下',
            author: '犬井あゆ'
          },
          {
            title: require("../static/images/rank/manga/m-3.jpg"),
            name: '甘えさせて雛森��ん！',
            author: 'tsuke'
          },
          {
            title: require("../static/images/rank/manga/m-4.jpg"),
            name: '君としらない夏になる',
            author: 'きぃやん'
          },
          {
            title: require("../static/images/rank/manga/m-5.jpg"),
            name: 'アンドロイドは経験人数に入りますか？？',
            author: '焼肉定食'
          },
          {
            title: require("../static/images/rank/manga/m-6.jpg"),
            name: 'スピカをつかまえて',
            author: '織日ちひろ'
          },
          {
            title: require("../static/images/rank/manga/m-7.jpg"),
            name: '今日はカノジョがいないから',
            author: '岩見樹代子'
          },
          {
            title: require("../static/images/rank/manga/m-8.jpg"),
            name: '女ともだちと結婚してみた。',
            author: '雨水汐'
          },
          {
            title: require("../static/images/rank/manga/m-9.jpg"),
            name: '踊り場にスカートが鳴る',
            author: 'うたたね游'
          },
          {
            title:require("../static/images/rank/manga/m-10.jpg"),
            name: '彩純ちゃんはレズ風俗に興味があります！',
            author: '伊月クロ'
          },
        ]
      }
    },
    methods: {

    }
  }
</script>

<style lang="less" scoped="scoped">
  .content {
    z-index: 2;
    position: relative;
    width: 100%;
    background-color: #ffffff;
    padding: 10px;
    margin-top: 0px;
    font-size: 17px;
    overflow-y: scroll;
    // height: 100%;
    // 背景设置
    &::after {
      content: "";
      position: absolute;
      z-index: 0;
      top: 50%;
      left: 50%;
      transform: translateX(-50%) translateY(-50%);
      width: 800px;
      height: 800px;
      border-radius: 50%;
      border: 1px solid rgba(0, 0, 0, 0.1);
    }

    .list {
      position: relative;
      z-index: 20;

      .title {
        display: flex;
        justify-content: center;
        align-items: baseline;
        margin-bottom: 50px;
        color: #000000;
        text-align: center;

        .name {
          font-size: 45px;
          margin-right: 8px;
        }

        .desc {
          font-size: 16px;
          font-family: '黑体';
        }
      }

      .list-contain {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;


        .item {
          width: 220px;
          height: 410px;
          margin-right: 20px;
          margin-bottom: 20px;
          transition: 0.4s;

          &:hover {
            opacity: 0.6;
          }

          .top {
            height: 280px;
            width: 220px;
            background-color: #ffff00;
            // background-image: url();
            background-size: 100%;
            box-shadow: 0 0 20px 0 rgb(0 0 0 / 20%);
            overflow: hidden;

            img {
              width: 100%;
            }
          }

          .bottom {
            padding: 10px 10px;

            .name {
              font-weight: 1000;
              margin-bottom: 10px;
            }

            .desc {
              font-size: 14px;
              font-family: '黑体';
              margin-bottom: 10px;
            }

            .time {
              font-size: 14px;
              font-family: '黑体';
            }
          }
        }
      }

    }
  }
</style>
