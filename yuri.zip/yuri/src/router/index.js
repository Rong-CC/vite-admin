/*
 * @Description:
 * @Author: rongcheng
 * @@后台人员: xxx
 * @Date: 2022-06-06 02:54:24
 * @LastEditors: rongcheng
 * @LastEditTime: 2022-06-06 20:30:19
 */
import Vue from 'vue'
import VueRouter from 'vue-router'
// import HomeView from '../views/HomeView.vue'
import HelloWorld from '../components/HelloWorld.vue'
// 引入首页
import Index from '../components/Index.vue'
// 引入论坛板块
import Forum from '../views/Forum.vue'
// 引入排行榜
import Leaderboard from '../views/Leaderboard.vue'
// 引入漫画模块
import Manga from '../views/Manga.vue'
// 引入小说排行榜单
import Shousetsu from '../components/Shousetsu.vue'
// 导入角色排行榜单
import Role from '../components/Role.vue'
// 引入评论详情
import CommentDetail from '../views/CommentDetail.vue'
// 引入登录页
import Land from '../views/Land.vue'
Vue.use(VueRouter)

const routes = [
  {
    path: '/Land',
    name: Land,
    component: Land
  },
  {
    path: '/',
    name: 'HelloWorld',
    component: HelloWorld,
    children: [{
      path: '/',
      component: Index
    },
    {
      path: '/Index',
      component: Index
    }
      // // 论坛板块路由
      // {
      //   path: '/Forum',
      //   name: 'Forum',
      //   component: Forum
      // },
      // {
      //   path: '/CommentDetail',
      //   name: 'CommentDetail',
      //   component: CommentDetail
      // },
      // // 漫画路由
      // {
      //   path: '/Manga',
      //   component: Manga
      // },
      // // 排行榜路由
      // {
      //   path: '/Leaderboard',
      //   name: 'Leaderboard',
      //   component: Leaderboard,
      //   children: [
      //     {
      //       path: '/',
      //       name: 'Shousetsu',
      //       component: Shousetsu
      //     },
      //     {
      //       path: '/Shousetsu',
      //       name: 'Shousetsu',
      //       component: Shousetsu
      //     },
      //     {
      //       path: '/Role',
      //       name: 'Role',
      //       component: Role
      //     }
      //   ]
      // }

    ]
  }

]

const router = new VueRouter({
  routes
})

export default router
