
// const { defineConfig } = require('@vue/cli-service')
'use strict'
const path = require('path')
function resolve (dir) {
  return path.join(__dirname, dir)
}
module.exports = {
  transpileDependencies: false,
  lintOnSave: false,
  // assetsDir: 'static',
  // assetsSubDirectory: 'static',
  parallel: false,
  publicPath: './',
  configureWebpack: {
    // provide the app's title in webpack's name field, so that
    // it can be accessed in index.html to inject the correct title.
    resolve: {
      alias: {
        '@': resolve('src')
      }
    }
  },
  css: {
    // css在所有环境下，都不单独打包为文件。这样是为了保证最小引入（只引入js）
    extract: false
  },
  productionSourceMap: false, // 生产环境是否生成 sourceMap 文件
  chainWebpack: config => {
    // 其他配置
    config.entry('main').add('babel-polyfill') // main是入口js文件
    // 其他配置
  }
}
